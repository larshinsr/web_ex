import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { RegularComponentComponent } from './regular-component/regular-component.component';

const routes: Routes = [
  { path: '', component: RegularComponentComponent }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class RegularRoutingModule { }
