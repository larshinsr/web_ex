import { Component } from '@angular/core';

@Component({
  selector: 'app-regular-component',
  templateUrl: './regular-component.component.html',
  styleUrls: ['./regular-component.component.css']
})
export class RegularComponentComponent {

}
