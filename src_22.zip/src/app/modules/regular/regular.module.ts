import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { RegularRoutingModule } from './regular-routing.module';
import { RegularComponentComponent } from './regular-component/regular-component.component';


@NgModule({
  declarations: [
    RegularComponentComponent
  ],
  imports: [
    CommonModule,
    RegularRoutingModule
  ]
})
export class RegularModule { }
