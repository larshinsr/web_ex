import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

const routes: Routes = [
  {
    path: 'regular',
    loadChildren: () => import('./modules/regular/regular.module').then(m => m.RegularModule)
  },
  {
    path: 'lazy',
    loadChildren: () => import('./modules/lazy/lazy.module').then(m => m.LazyModule)
  },
  // Перенаправление на regular для демонстрации
  {
    path: '',
    redirectTo: 'regular',
    pathMatch: 'full'
  }
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
