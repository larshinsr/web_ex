import { HttpClient } from '@angular/common/http';
import { Component } from '@angular/core';

@Component({
  selector: 'app-my-form',
  templateUrl: './my-form.component.html',
  styleUrls: ['./my-form.component.css']
})
export class MyFormComponent {
  formData = {
    field1: "",
    field2: "",
    field3: "",
    field4: ""
  };
  constructor(private http: HttpClient) { }
  onSubmit(){
    this.http.post('http://localhost:3000/records', this.formData).subscribe(
      (response)=>{
        console.log(response);
      },
      (error)=>{
        console.error(error);
      }
      )
  }
}
