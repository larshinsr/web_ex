export class Record {
    constructor(
        public field1: string,
        public field2: string,
        public id?: number
    ) { }

}