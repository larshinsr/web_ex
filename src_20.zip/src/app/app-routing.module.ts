import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { ServComponent } from './serv/serv.component';

const routes: Routes = [
  { path: 'serv', component: ServComponent }
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
