import { Component } from '@angular/core';
import { Record } from '../record.model';
import { RecordService } from '../record.service';
@Component({
  selector: 'app-serv',
  templateUrl: './serv.component.html',
  styleUrls: ['./serv.component.css']
})
export class ServComponent {
  rec:Record|null = null;
  constructor(private recordService:RecordService){}
  ngOnInit(): void {
  }
 firstElement():void
 {
   this.recordService.getFirstRecord().subscribe((rec:Record)=>{
     this.rec=rec;
   });
 }
}
