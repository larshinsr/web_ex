import { Injectable } from "@angular/core";
import { HttpClient } from "@angular/common/http";
import { Record } from "./record.model"; // Make sure this path is correct
import { Observable } from "rxjs";
import { map } from 'rxjs/operators';

@Injectable({
  providedIn: 'root' // Use providedIn for a singleton service
})
export class RecordService {
  private url = 'http://localhost:3000/records'; // Use 'records' to match your db.json

  constructor(private http: HttpClient) { }

  getFirstRecord(): Observable<Record> {
    // Since you're only getting the first record, no need for id parameter
    return this.http.get<Record[]>(this.url)
      .pipe(
        map(records => records[0]) // Directly access the first record
      );
  }
}